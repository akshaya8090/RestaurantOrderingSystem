package restaurant.dao;

import restaurant.model.Order;
import restaurant.model.OrderItem;
import restaurant.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * OrderDAO - Data Access Object for Order operations.
 * Handles inserts and queries for the 'orders' and 'order_items' tables.
 */
public class OrderDAO {

    /**
     * Saves a new order (and its items) to the database using a transaction.
     * Returns the generated order ID.
     */
    public int placeOrder(Order order) throws SQLException {
        Connection conn = DBConnection.getConnection();
        conn.setAutoCommit(false); // Begin transaction

        try {
            // Step 1: Insert into orders table
            String orderSQL = "INSERT INTO orders (customer_name, status) VALUES (?, ?)";
            int generatedOrderId;

            try (PreparedStatement ps = conn.prepareStatement(orderSQL, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, order.getCustomerName());
                ps.setString(2, "Placed");
                ps.executeUpdate();

                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        generatedOrderId = keys.getInt(1);
                        order.setOrderId(generatedOrderId);
                    } else {
                        throw new SQLException("Failed to retrieve generated Order ID.");
                    }
                }
            }

            // Step 2: Insert each order item
            String itemSQL = "INSERT INTO order_items (order_id, item_id, quantity, unit_price) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = conn.prepareStatement(itemSQL)) {
                for (OrderItem oi : order.getItems()) {
                    ps.setInt(1, generatedOrderId);
                    ps.setInt(2, oi.getItemId());
                    ps.setInt(3, oi.getQuantity());
                    ps.setDouble(4, oi.getUnitPrice());
                    ps.addBatch();
                }
                ps.executeBatch();
            }

            conn.commit(); // Commit transaction
            return generatedOrderId;

        } catch (SQLException e) {
            conn.rollback(); // Rollback on error
            throw e;
        } finally {
            conn.setAutoCommit(true);
        }
    }

    /**
     * Update the status of an order (e.g., Placed → In Progress → Ready → Billed).
     */
    public boolean updateOrderStatus(int orderId, String newStatus) throws SQLException {
        String sql = "UPDATE orders SET status = ? WHERE order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newStatus);
            ps.setInt(2, orderId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Fetch all items belonging to a specific order (with item names via JOIN).
     */
    public List<OrderItem> getOrderItems(int orderId) throws SQLException {
        List<OrderItem> items = new ArrayList<>();
        String sql = "SELECT oi.order_item_id, oi.order_id, oi.item_id, m.item_name, oi.quantity, oi.unit_price " +
                     "FROM order_items oi JOIN menu m ON oi.item_id = m.item_id " +
                     "WHERE oi.order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    items.add(new OrderItem(
                            rs.getInt("order_item_id"),
                            rs.getInt("order_id"),
                            rs.getInt("item_id"),
                            rs.getString("item_name"),
                            rs.getInt("quantity"),
                            rs.getDouble("unit_price")
                    ));
                }
            }
        }
        return items;
    }

    /**
     * Fetch all orders currently in the system.
     */
    public List<Order> getAllOrders() throws SQLException {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT order_id, customer_name, status FROM orders ORDER BY order_id DESC";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                orders.add(new Order(
                        rs.getInt("order_id"),
                        rs.getString("customer_name"),
                        rs.getString("status")
                ));
            }
        }
        return orders;
    }

    /**
     * Fetch a single order by its ID.
     */
    public Order getOrderById(int orderId) throws SQLException {
        String sql = "SELECT order_id, customer_name, status FROM orders WHERE order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Order order = new Order(
                            rs.getInt("order_id"),
                            rs.getString("customer_name"),
                            rs.getString("status")
                    );
                    order.getItems().addAll(getOrderItems(orderId));
                    return order;
                }
            }
        }
        return null;
    }
}
