package restaurant.dao;

import restaurant.model.MenuItem;
import restaurant.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * MenuDAO - Data Access Object for Menu operations.
 * All direct SQL interactions with the 'menu' table live here.
 */
public class MenuDAO {

    /**
     * Fetch all available menu items from the database.
     */
    public List<MenuItem> getAllAvailableItems() throws SQLException {
        List<MenuItem> menuList = new ArrayList<>();
        String sql = "SELECT item_id, item_name, category, price, availability FROM menu ORDER BY category, item_name";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                menuList.add(new MenuItem(
                        rs.getInt("item_id"),
                        rs.getString("item_name"),
                        rs.getString("category"),
                        rs.getDouble("price"),
                        rs.getInt("availability") == 1
                ));
            }
        }
        return menuList;
    }

    /**
     * Fetch a single menu item by its ID.
     */
    public MenuItem getItemById(int itemId) throws SQLException {
        String sql = "SELECT item_id, item_name, category, price, availability FROM menu WHERE item_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, itemId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new MenuItem(
                            rs.getInt("item_id"),
                            rs.getString("item_name"),
                            rs.getString("category"),
                            rs.getDouble("price"),
                            rs.getInt("availability") == 1
                    );
                }
            }
        }
        return null; // item not found
    }

    /**
     * Add a new item to the menu.
     */
    public boolean addMenuItem(String name, String category, double price) throws SQLException {
        String sql = "INSERT INTO menu (item_name, category, price, availability) VALUES (?, ?, ?, 1)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, name);
            ps.setString(2, category);
            ps.setDouble(3, price);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Update availability of a menu item (enable/disable).
     */
    public boolean updateAvailability(int itemId, boolean available) throws SQLException {
        String sql = "UPDATE menu SET availability = ? WHERE item_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, available ? 1 : 0);
            ps.setInt(2, itemId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Update price of a menu item.
     */
    public boolean updatePrice(int itemId, double newPrice) throws SQLException {
        String sql = "UPDATE menu SET price = ? WHERE item_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setDouble(1, newPrice);
            ps.setInt(2, itemId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Delete a menu item by ID.
     */
    public boolean deleteMenuItem(int itemId) throws SQLException {
        String sql = "DELETE FROM menu WHERE item_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, itemId);
            return ps.executeUpdate() > 0;
        }
    }
}
