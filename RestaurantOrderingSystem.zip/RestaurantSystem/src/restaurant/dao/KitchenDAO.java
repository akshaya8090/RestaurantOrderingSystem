package restaurant.dao;

import restaurant.model.OrderItem;
import restaurant.util.DBConnection;

import java.sql.*;
import java.util.List;

/**
 * KitchenDAO - Data Access Object for Kitchen Queue operations.
 * Handles inserts and status updates in the 'kitchen_queue' table.
 */
public class KitchenDAO {

    /**
     * Pushes all items of an order into the kitchen queue automatically.
     * Called immediately after an order is placed.
     */
    public void pushToKitchen(int orderId, List<OrderItem> items) throws SQLException {
        String sql = "INSERT INTO kitchen_queue (order_id, item_name, quantity, kitchen_status) VALUES (?, ?, ?, 'In Progress')";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            for (OrderItem oi : items) {
                ps.setInt(1, orderId);
                ps.setString(2, oi.getItemName());
                ps.setInt(3, oi.getQuantity());
                ps.addBatch();
            }
            ps.executeBatch();
            System.out.println("[Kitchen] Order #" + orderId + " pushed to kitchen queue.");
        }
    }

    /**
     * Mark all kitchen items for a given order as 'Ready'.
     */
    public boolean markOrderReady(int orderId) throws SQLException {
        String sql = "UPDATE kitchen_queue SET kitchen_status = 'Ready' WHERE order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            return ps.executeUpdate() > 0;
        }
    }

    /**
     * Display current kitchen queue (all In Progress orders).
     */
    public void printKitchenQueue() throws SQLException {
        String sql = "SELECT kq.queue_id, kq.order_id, o.customer_name, kq.item_name, kq.quantity, kq.kitchen_status " +
                     "FROM kitchen_queue kq JOIN orders o ON kq.order_id = o.order_id " +
                     "WHERE kq.kitchen_status = 'In Progress' ORDER BY kq.queue_id";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            System.out.println("\n======= KITCHEN QUEUE (In Progress) =======");
            boolean hasRows = false;
            while (rs.next()) {
                hasRows = true;
                System.out.printf("  Queue#%-3d | Order#%-3d | Customer: %-15s | %-22s x%d | %s%n",
                        rs.getInt("queue_id"),
                        rs.getInt("order_id"),
                        rs.getString("customer_name"),
                        rs.getString("item_name"),
                        rs.getInt("quantity"),
                        rs.getString("kitchen_status"));
            }
            if (!hasRows) System.out.println("  No pending orders in kitchen.");
            System.out.println("===========================================\n");
        }
    }
}
