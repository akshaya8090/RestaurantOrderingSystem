package restaurant.dao;

import restaurant.model.Bill;
import restaurant.util.DBConnection;

import java.sql.*;

/**
 * BillingDAO - Data Access Object for Billing operations.
 * Handles bill generation and storage in the 'billing' table.
 */
public class BillingDAO {

    private static final double TAX_PERCENT = 5.0;

    /**
     * Generates a bill for the given order and stores it in the billing table.
     * Returns the Bill object.
     */
    public Bill generateBill(int orderId, double subtotal) throws SQLException {
        Bill bill = new Bill(orderId, subtotal, TAX_PERCENT);

        String sql = "INSERT INTO billing (order_id, subtotal, tax_percent, tax_amount, total_amount) " +
                     "VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, orderId);
            ps.setDouble(2, bill.getSubtotal());
            ps.setDouble(3, bill.getTaxPercent());
            ps.setDouble(4, bill.getTaxAmount());
            ps.setDouble(5, bill.getTotalAmount());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    bill.setBillId(keys.getInt(1));
                }
            }
        }
        return bill;
    }

    /**
     * Check if a bill already exists for the given order.
     */
    public boolean billExists(int orderId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM billing WHERE order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    /**
     * Fetch an existing bill for an order.
     */
    public Bill getBillByOrderId(int orderId) throws SQLException {
        String sql = "SELECT bill_id, subtotal, tax_percent, tax_amount, total_amount FROM billing WHERE order_id = ?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    Bill bill = new Bill(orderId, rs.getDouble("subtotal"), rs.getDouble("tax_percent"));
                    bill.setBillId(rs.getInt("bill_id"));
                    return bill;
                }
            }
        }
        return null;
    }
}
