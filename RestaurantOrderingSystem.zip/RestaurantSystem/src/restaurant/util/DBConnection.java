package restaurant.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DBConnection - Singleton utility class to manage MySQL connection.
 * Uses a single shared connection throughout the application lifecycle.
 */
public class DBConnection {

    private static final String URL      = "jdbc:mysql://localhost:3306/restaurant_db";
    private static final String USER     = "root";        // Change to your MySQL username
    private static final String PASSWORD = "your_password"; // Change to your MySQL password

    private static Connection connection = null;

    // Private constructor - prevents instantiation
    private DBConnection() {}

    /**
     * Returns a shared Connection instance (creates one if not exists).
     */
    public static Connection getConnection() throws SQLException {
        if (connection == null || connection.isClosed()) {
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                connection = DriverManager.getConnection(URL, USER, PASSWORD);
                System.out.println("[DB] Connected to restaurant_db successfully.");
            } catch (ClassNotFoundException e) {
                throw new SQLException("MySQL JDBC Driver not found. Add mysql-connector-java to your classpath.", e);
            }
        }
        return connection;
    }

    /**
     * Closes the connection when the application exits.
     */
    public static void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("[DB] Connection closed.");
            } catch (SQLException e) {
                System.err.println("[DB] Error closing connection: " + e.getMessage());
            }
        }
    }
}
