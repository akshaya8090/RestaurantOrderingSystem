package restaurant.model;

/**
 * Bill - Model class representing a generated invoice for an order.
 */
public class Bill {

    private int    billId;
    private int    orderId;
    private double subtotal;
    private double taxPercent;
    private double taxAmount;
    private double totalAmount;

    public Bill(int orderId, double subtotal, double taxPercent) {
        this.orderId    = orderId;
        this.subtotal   = subtotal;
        this.taxPercent = taxPercent;
        this.taxAmount  = Math.round((subtotal * taxPercent / 100.0) * 100.0) / 100.0;
        this.totalAmount = Math.round((subtotal + this.taxAmount) * 100.0) / 100.0;
    }

    // Getters
    public int    getBillId()      { return billId; }
    public int    getOrderId()     { return orderId; }
    public double getSubtotal()    { return subtotal; }
    public double getTaxPercent()  { return taxPercent; }
    public double getTaxAmount()   { return taxAmount; }
    public double getTotalAmount() { return totalAmount; }

    public void setBillId(int billId) { this.billId = billId; }
}
