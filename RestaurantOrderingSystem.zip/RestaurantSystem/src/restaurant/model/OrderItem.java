package restaurant.model;

/**
 * OrderItem - Represents a single line item within an Order.
 * Links a MenuItem with a chosen quantity.
 */
public class OrderItem {

    private int    orderItemId;
    private int    orderId;
    private int    itemId;
    private String itemName;
    private int    quantity;
    private double unitPrice;

    // Constructor used when customer places order
    public OrderItem(int itemId, String itemName, int quantity, double unitPrice) {
        this.itemId    = itemId;
        this.itemName  = itemName;
        this.quantity  = quantity;
        this.unitPrice = unitPrice;
    }

    // Full constructor (loading from DB)
    public OrderItem(int orderItemId, int orderId, int itemId, String itemName, int quantity, double unitPrice) {
        this.orderItemId = orderItemId;
        this.orderId     = orderId;
        this.itemId      = itemId;
        this.itemName    = itemName;
        this.quantity    = quantity;
        this.unitPrice   = unitPrice;
    }

    // Getters
    public int    getOrderItemId() { return orderItemId; }
    public int    getOrderId()     { return orderId; }
    public int    getItemId()      { return itemId; }
    public String getItemName()    { return itemName; }
    public int    getQuantity()    { return quantity; }
    public double getUnitPrice()   { return unitPrice; }
    public double getLineTotal()   { return unitPrice * quantity; }

    @Override
    public String toString() {
        return String.format("  %-22s x%d  @  Rs.%-8.2f =  Rs.%.2f",
                itemName, quantity, unitPrice, getLineTotal());
    }
}
