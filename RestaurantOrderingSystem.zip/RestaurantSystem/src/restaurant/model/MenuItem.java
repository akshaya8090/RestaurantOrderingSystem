package restaurant.model;

/**
 * MenuItem - Model class representing a food item in the menu.
 * Demonstrates ENCAPSULATION using private fields and public getters/setters.
 */
public class MenuItem {

    private int    itemId;
    private String itemName;
    private String category;
    private double price;
    private boolean available;

    // Constructor
    public MenuItem(int itemId, String itemName, String category, double price, boolean available) {
        this.itemId    = itemId;
        this.itemName  = itemName;
        this.category  = category;
        this.price     = price;
        this.available = available;
    }

    // Getters
    public int    getItemId()    { return itemId; }
    public String getItemName()  { return itemName; }
    public String getCategory()  { return category; }
    public double getPrice()     { return price; }
    public boolean isAvailable() { return available; }

    // Setters
    public void setPrice(double price)          { this.price = price; }
    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return String.format("  [%2d] %-22s | %-12s | Rs. %.2f%s",
                itemId, itemName, category, price, available ? "" : " [NOT AVAILABLE]");
    }
}
