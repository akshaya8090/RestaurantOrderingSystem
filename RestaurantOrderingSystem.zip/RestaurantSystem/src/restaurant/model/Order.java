package restaurant.model;

import java.util.ArrayList;
import java.util.List;

/**
 * Order - Model class representing a customer order.
 * Contains a list of OrderItem objects (composition).
 */
public class Order {

    private int    orderId;
    private String customerName;
    private String status;
    private List<OrderItem> items;

    // Constructor for a new order (before DB insert)
    public Order(String customerName) {
        this.customerName = customerName;
        this.status       = "Placed";
        this.items        = new ArrayList<>();
    }

    // Constructor when loading from DB
    public Order(int orderId, String customerName, String status) {
        this.orderId      = orderId;
        this.customerName = customerName;
        this.status       = status;
        this.items        = new ArrayList<>();
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    // Getters & Setters
    public int    getOrderId()      { return orderId; }
    public String getCustomerName() { return customerName; }
    public String getStatus()       { return status; }
    public List<OrderItem> getItems() { return items; }

    public void setOrderId(int orderId) { this.orderId = orderId; }
    public void setStatus(String status) { this.status = status; }

    /**
     * Calculates the subtotal of all items in this order.
     */
    public double calculateSubtotal() {
        double total = 0;
        for (OrderItem oi : items) {
            total += oi.getUnitPrice() * oi.getQuantity();
        }
        return total;
    }
}
