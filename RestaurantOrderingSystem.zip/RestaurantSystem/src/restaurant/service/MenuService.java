package restaurant.service;

import restaurant.dao.MenuDAO;
import restaurant.model.MenuItem;

import java.sql.SQLException;
import java.util.List;

/**
 * MenuService - Business logic layer for Menu operations.
 * Calls MenuDAO and handles display formatting.
 */
public class MenuService {

    private final MenuDAO menuDAO = new MenuDAO();

    /**
     * Prints the full menu grouped by category.
     */
    public void displayMenu() throws SQLException {
        List<MenuItem> items = menuDAO.getAllAvailableItems();

        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║           RESTAURANT MENU                            ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");

        String currentCategory = "";
        for (MenuItem item : items) {
            if (!item.getCategory().equals(currentCategory)) {
                currentCategory = item.getCategory();
                System.out.println("\n  --- " + currentCategory.toUpperCase() + " ---");
            }
            System.out.println(item.toString());
        }
        System.out.println("\n────────────────────────────────────────────────────────\n");
    }

    /**
     * Validates and returns a menu item by ID. Returns null if invalid or unavailable.
     */
    public MenuItem getValidItem(int itemId) throws SQLException {
        MenuItem item = menuDAO.getItemById(itemId);
        if (item == null) {
            System.out.println("[!] Item ID " + itemId + " does not exist.");
            return null;
        }
        if (!item.isAvailable()) {
            System.out.println("[!] Sorry, '" + item.getItemName() + "' is currently not available.");
            return null;
        }
        return item;
    }

    /**
     * Admin: Add a new item to the menu.
     */
    public void addItem(String name, String category, double price) throws SQLException {
        if (menuDAO.addMenuItem(name, category, price)) {
            System.out.println("[Menu] Item '" + name + "' added successfully.");
        } else {
            System.out.println("[Menu] Failed to add item.");
        }
    }

    /**
     * Admin: Toggle availability of an item.
     */
    public void toggleAvailability(int itemId, boolean available) throws SQLException {
        MenuItem item = menuDAO.getItemById(itemId);
        if (item == null) { System.out.println("[!] Item not found."); return; }
        menuDAO.updateAvailability(itemId, available);
        System.out.println("[Menu] '" + item.getItemName() + "' is now " + (available ? "AVAILABLE" : "UNAVAILABLE") + ".");
    }

    /**
     * Admin: Update price of an item.
     */
    public void updatePrice(int itemId, double newPrice) throws SQLException {
        MenuItem item = menuDAO.getItemById(itemId);
        if (item == null) { System.out.println("[!] Item not found."); return; }
        menuDAO.updatePrice(itemId, newPrice);
        System.out.printf("[Menu] Price of '%s' updated to Rs. %.2f%n", item.getItemName(), newPrice);
    }
}
