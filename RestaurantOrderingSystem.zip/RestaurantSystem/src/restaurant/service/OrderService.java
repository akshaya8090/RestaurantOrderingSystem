package restaurant.service;

import restaurant.dao.KitchenDAO;
import restaurant.dao.OrderDAO;
import restaurant.model.MenuItem;
import restaurant.model.Order;
import restaurant.model.OrderItem;

import java.sql.SQLException;
import java.util.List;

/**
 * OrderService - Business logic for placing and managing orders.
 * Coordinates between OrderDAO and KitchenDAO.
 */
public class OrderService {

    private final OrderDAO    orderDAO    = new OrderDAO();
    private final KitchenDAO  kitchenDAO  = new KitchenDAO();
    private final MenuService menuService = new MenuService();

    /**
     * Creates an Order object from the customer's chosen items.
     * Returns the placed Order with its DB-assigned ID.
     */
    public Order placeOrder(String customerName, int[] itemIds, int[] quantities) throws SQLException {
        Order order = new Order(customerName);

        for (int i = 0; i < itemIds.length; i++) {
            MenuItem item = menuService.getValidItem(itemIds[i]);
            if (item == null) continue; // skip invalid/unavailable items

            OrderItem orderItem = new OrderItem(
                    item.getItemId(),
                    item.getItemName(),
                    quantities[i],
                    item.getPrice()
            );
            order.addItem(orderItem);
        }

        if (order.getItems().isEmpty()) {
            System.out.println("[!] No valid items selected. Order cancelled.");
            return null;
        }

        // Save order to DB (transaction inside DAO)
        int orderId = orderDAO.placeOrder(order);
        System.out.println("\n[Order] Order #" + orderId + " placed successfully for " + customerName + "!");

        // Automatically push to kitchen
        kitchenDAO.pushToKitchen(orderId, order.getItems());

        return order;
    }

    /**
     * Prints all items in a placed order as a receipt preview.
     */
    public void printOrderSummary(Order order) {
        System.out.println("\n──────────── ORDER SUMMARY ────────────");
        System.out.println("  Order ID  : #" + order.getOrderId());
        System.out.println("  Customer  : " + order.getCustomerName());
        System.out.println("  Status    : " + order.getStatus());
        System.out.println("  Items:");
        for (OrderItem oi : order.getItems()) {
            System.out.println(oi.toString());
        }
        System.out.printf("  Subtotal  :  Rs. %.2f%n", order.calculateSubtotal());
        System.out.println("───────────────────────────────────────\n");
    }

    /**
     * Returns the full order including items by ID.
     */
    public Order getOrderById(int orderId) throws SQLException {
        return orderDAO.getOrderById(orderId);
    }

    /**
     * Updates status of an order.
     */
    public boolean updateStatus(int orderId, String status) throws SQLException {
        return orderDAO.updateOrderStatus(orderId, status);
    }

    /**
     * View all orders in the system.
     */
    public void viewAllOrders() throws SQLException {
        List<Order> orders = orderDAO.getAllOrders();
        System.out.println("\n════════════ ALL ORDERS ════════════");
        if (orders.isEmpty()) {
            System.out.println("  No orders found.");
        } else {
            for (Order o : orders) {
                System.out.printf("  Order#%-4d | Customer: %-15s | Status: %s%n",
                        o.getOrderId(), o.getCustomerName(), o.getStatus());
            }
        }
        System.out.println("════════════════════════════════════\n");
    }
}
