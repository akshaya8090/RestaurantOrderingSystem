package restaurant.service;

import restaurant.dao.BillingDAO;
import restaurant.dao.KitchenDAO;
import restaurant.dao.OrderDAO;
import restaurant.model.Bill;
import restaurant.model.Order;
import restaurant.model.OrderItem;

import java.sql.SQLException;

/**
 * BillingService - Business logic for invoice generation.
 * Validates order state, generates bill, prints formatted invoice.
 */
public class BillingService {

    private final BillingDAO billingDAO = new BillingDAO();
    private final OrderDAO   orderDAO   = new OrderDAO();
    private final KitchenDAO kitchenDAO = new KitchenDAO();

    /**
     * Generates a bill for a given order ID.
     * Validates: order must exist, must not already be billed.
     */
    public Bill generateBill(int orderId) throws SQLException {
        // Check if already billed
        if (billingDAO.billExists(orderId)) {
            System.out.println("[Billing] Bill already generated for Order #" + orderId + ".");
            return billingDAO.getBillByOrderId(orderId);
        }

        // Load order
        Order order = orderDAO.getOrderById(orderId);
        if (order == null) {
            System.out.println("[!] Order #" + orderId + " not found.");
            return null;
        }

        // Mark kitchen as Ready + order as Billed
        kitchenDAO.markOrderReady(orderId);
        orderDAO.updateOrderStatus(orderId, "Billed");

        // Generate and save bill
        double subtotal = order.calculateSubtotal();
        Bill bill = billingDAO.generateBill(orderId, subtotal);

        // Print the invoice
        printInvoice(order, bill);
        return bill;
    }

    /**
     * Prints a formatted invoice to the console.
     */
    private void printInvoice(Order order, Bill bill) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║                   RESTAURANT INVOICE                ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");
        System.out.printf("  Bill ID   : #%d%n", bill.getBillId());
        System.out.printf("  Order ID  : #%d%n", order.getOrderId());
        System.out.printf("  Customer  : %s%n", order.getCustomerName());
        System.out.println("────────────────────────────────────────────────────────");
        System.out.printf("  %-22s  %5s  %10s  %10s%n", "Item", "Qty", "Unit Price", "Total");
        System.out.println("────────────────────────────────────────────────────────");

        for (OrderItem oi : order.getItems()) {
            System.out.printf("  %-22s  %5d  Rs.%7.2f  Rs.%7.2f%n",
                    oi.getItemName(), oi.getQuantity(), oi.getUnitPrice(), oi.getLineTotal());
        }

        System.out.println("────────────────────────────────────────────────────────");
        System.out.printf("  %-35s  Rs.%7.2f%n", "Subtotal", bill.getSubtotal());
        System.out.printf("  %-35s  Rs.%7.2f%n",
                String.format("Tax (%.0f%%)", bill.getTaxPercent()), bill.getTaxAmount());
        System.out.println("════════════════════════════════════════════════════════");
        System.out.printf("  %-35s  Rs.%7.2f%n", "TOTAL AMOUNT", bill.getTotalAmount());
        System.out.println("════════════════════════════════════════════════════════");
        System.out.println("       Thank you for dining with us! Visit again.       ");
        System.out.println("════════════════════════════════════════════════════════\n");
    }
}
