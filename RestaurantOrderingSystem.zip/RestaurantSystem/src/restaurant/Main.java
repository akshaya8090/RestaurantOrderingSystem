package restaurant;

import restaurant.dao.KitchenDAO;
import restaurant.model.Order;
import restaurant.service.BillingService;
import restaurant.service.MenuService;
import restaurant.service.OrderService;
import restaurant.util.DBConnection;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Main - Entry point for the Automatic Restaurant Ordering Management System.
 *
 * Features:
 *  1. View Menu
 *  2. Place Order        → auto-pushes to kitchen
 *  3. View Kitchen Queue → see live pending orders
 *  4. Generate Bill      → auto-marks order ready + prints invoice
 *  5. View All Orders
 *  6. Admin: Add Menu Item
 *  0. Exit
 */
public class Main {

    private static final Scanner       scanner        = new Scanner(System.in);
    private static final MenuService   menuService    = new MenuService();
    private static final OrderService  orderService   = new OrderService();
    private static final BillingService billingService = new BillingService();
    private static final KitchenDAO    kitchenDAO     = new KitchenDAO();

    public static void main(String[] args) {
        System.out.println("\n╔══════════════════════════════════════════════════════╗");
        System.out.println("║   Automatic Restaurant Ordering Management System    ║");
        System.out.println("║                  Developed by Thati Akshaya         ║");
        System.out.println("╚══════════════════════════════════════════════════════╝");

        // Verify DB connection at startup
        try {
            DBConnection.getConnection();
        } catch (SQLException e) {
            System.err.println("[FATAL] Cannot connect to database: " + e.getMessage());
            System.err.println("Please check DBConnection.java and make sure MySQL is running.");
            return;
        }

        boolean running = true;
        while (running) {
            printMainMenu();
            int choice = readInt("Enter choice: ");

            try {
                switch (choice) {
                    case 1 -> menuService.displayMenu();
                    case 2 -> handlePlaceOrder();
                    case 3 -> kitchenDAO.printKitchenQueue();
                    case 4 -> handleGenerateBill();
                    case 5 -> orderService.viewAllOrders();
                    case 6 -> handleAdminAddItem();
                    case 0 -> {
                        System.out.println("\nThank you! Exiting system...");
                        running = false;
                    }
                    default -> System.out.println("[!] Invalid option. Please try again.");
                }
            } catch (SQLException e) {
                System.err.println("[DB Error] " + e.getMessage());
            }
        }

        DBConnection.closeConnection();
        scanner.close();
    }

    // ─────────────────────────────────────────────────────────────
    //  MAIN MENU DISPLAY
    // ─────────────────────────────────────────────────────────────
    private static void printMainMenu() {
        System.out.println("\n┌──────────────────────────────────┐");
        System.out.println("│           MAIN MENU              │");
        System.out.println("├──────────────────────────────────┤");
        System.out.println("│  1. View Menu                    │");
        System.out.println("│  2. Place Order                  │");
        System.out.println("│  3. View Kitchen Queue           │");
        System.out.println("│  4. Generate Bill                │");
        System.out.println("│  5. View All Orders              │");
        System.out.println("│  6. Admin: Add Menu Item         │");
        System.out.println("│  0. Exit                         │");
        System.out.println("└──────────────────────────────────┘");
    }

    // ─────────────────────────────────────────────────────────────
    //  PLACE ORDER FLOW
    // ─────────────────────────────────────────────────────────────
    private static void handlePlaceOrder() throws SQLException {
        menuService.displayMenu();

        System.out.print("Enter customer name: ");
        String customerName = scanner.nextLine().trim();
        if (customerName.isEmpty()) { System.out.println("[!] Name cannot be empty."); return; }

        List<Integer> itemIdList   = new ArrayList<>();
        List<Integer> quantityList = new ArrayList<>();

        System.out.println("Enter items (type 0 as Item ID when done):");
        while (true) {
            int itemId = readInt("  Item ID: ");
            if (itemId == 0) break;
            int qty = readInt("  Quantity: ");
            if (qty <= 0) { System.out.println("[!] Quantity must be at least 1."); continue; }
            itemIdList.add(itemId);
            quantityList.add(qty);
        }

        if (itemIdList.isEmpty()) { System.out.println("[!] No items selected."); return; }

        int[] itemIds   = itemIdList.stream().mapToInt(Integer::intValue).toArray();
        int[] quantities = quantityList.stream().mapToInt(Integer::intValue).toArray();

        Order order = orderService.placeOrder(customerName, itemIds, quantities);
        if (order != null) {
            orderService.printOrderSummary(order);
        }
    }

    // ─────────────────────────────────────────────────────────────
    //  GENERATE BILL FLOW
    // ─────────────────────────────────────────────────────────────
    private static void handleGenerateBill() throws SQLException {
        orderService.viewAllOrders();
        int orderId = readInt("Enter Order ID to generate bill: ");
        billingService.generateBill(orderId);
    }

    // ─────────────────────────────────────────────────────────────
    //  ADMIN: ADD MENU ITEM FLOW
    // ─────────────────────────────────────────────────────────────
    private static void handleAdminAddItem() throws SQLException {
        System.out.print("Item Name    : ");
        String name = scanner.nextLine().trim();
        System.out.print("Category     : ");
        String category = scanner.nextLine().trim();
        double price = readDouble("Price (Rs.)  : ");
        menuService.addItem(name, category, price);
    }

    // ─────────────────────────────────────────────────────────────
    //  INPUT HELPERS
    // ─────────────────────────────────────────────────────────────
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                int val = Integer.parseInt(scanner.nextLine().trim());
                return val;
            } catch (NumberFormatException e) {
                System.out.println("[!] Please enter a valid number.");
            }
        }
    }

    private static double readDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                double val = Double.parseDouble(scanner.nextLine().trim());
                return val;
            } catch (NumberFormatException e) {
                System.out.println("[!] Please enter a valid number.");
            }
        }
    }
}
