-- ============================================================
--  Automatic Restaurant Ordering Management System
--  Database Schema + Sample Data
--  Run this file in MySQL before starting the application
-- ============================================================

CREATE DATABASE IF NOT EXISTS restaurant_db;
USE restaurant_db;

-- ---------------------------------------------------------------
-- 1. MENU TABLE
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS menu (
    item_id       INT AUTO_INCREMENT PRIMARY KEY,
    item_name     VARCHAR(100) NOT NULL,
    category      VARCHAR(50)  NOT NULL,
    price         DECIMAL(8,2) NOT NULL,
    availability  TINYINT(1)   DEFAULT 1    -- 1 = available, 0 = not available
);

-- ---------------------------------------------------------------
-- 2. ORDERS TABLE
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS orders (
    order_id       INT AUTO_INCREMENT PRIMARY KEY,
    customer_name  VARCHAR(100) NOT NULL,
    order_time     TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    status         VARCHAR(30)  DEFAULT 'Placed'   -- Placed, In Progress, Ready, Billed
);

-- ---------------------------------------------------------------
-- 3. ORDER ITEMS TABLE  (one order can have many items)
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS order_items (
    order_item_id  INT AUTO_INCREMENT PRIMARY KEY,
    order_id       INT           NOT NULL,
    item_id        INT           NOT NULL,
    quantity       INT           NOT NULL,
    unit_price     DECIMAL(8,2)  NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(order_id),
    FOREIGN KEY (item_id)  REFERENCES menu(item_id)
);

-- ---------------------------------------------------------------
-- 4. KITCHEN QUEUE TABLE
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS kitchen_queue (
    queue_id        INT AUTO_INCREMENT PRIMARY KEY,
    order_id        INT          NOT NULL,
    item_name       VARCHAR(100) NOT NULL,
    quantity        INT          NOT NULL,
    kitchen_status  VARCHAR(30)  DEFAULT 'In Progress',  -- In Progress, Ready
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- ---------------------------------------------------------------
-- 5. BILLING TABLE
-- ---------------------------------------------------------------
CREATE TABLE IF NOT EXISTS billing (
    bill_id       INT AUTO_INCREMENT PRIMARY KEY,
    order_id      INT           NOT NULL UNIQUE,
    subtotal      DECIMAL(10,2) NOT NULL,
    tax_percent   DECIMAL(5,2)  DEFAULT 5.00,
    tax_amount    DECIMAL(10,2) NOT NULL,
    total_amount  DECIMAL(10,2) NOT NULL,
    bill_time     TIMESTAMP     DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_id) REFERENCES orders(order_id)
);

-- ---------------------------------------------------------------
-- SAMPLE MENU DATA
-- ---------------------------------------------------------------
INSERT INTO menu (item_name, category, price, availability) VALUES
('Veg Burger',       'Burgers',   80.00,  1),
('Chicken Burger',   'Burgers',   120.00, 1),
('Paneer Pizza',     'Pizza',     220.00, 1),
('Chicken Pizza',    'Pizza',     260.00, 1),
('Veg Fried Rice',   'Rice',      130.00, 1),
('Egg Fried Rice',   'Rice',      150.00, 1),
('Masala Dosa',      'Breakfast', 70.00,  1),
('Idli Sambar',      'Breakfast', 60.00,  1),
('Mango Lassi',      'Drinks',    80.00,  1),
('Cold Coffee',      'Drinks',    90.00,  1),
('French Fries',     'Snacks',    100.00, 1),
('Veg Spring Roll',  'Snacks',    110.00, 0);
