# Automatic Restaurant Ordering Management System
### Developed by: Thati Akshaya | June 2025

---

## Project Structure

```
RestaurantSystem/
├── sql/
│   └── schema.sql                         ← Run this in MySQL first
└── src/
    └── restaurant/
        ├── Main.java                       ← Entry point (run this)
        ├── model/
        │   ├── MenuItem.java
        │   ├── Order.java
        │   ├── OrderItem.java
        │   └── Bill.java
        ├── dao/
        │   ├── MenuDAO.java
        │   ├── OrderDAO.java
        │   ├── KitchenDAO.java
        │   └── BillingDAO.java
        ├── service/
        │   ├── MenuService.java
        │   ├── OrderService.java
        │   └── BillingService.java
        └── util/
            └── DBConnection.java
```

---

## Setup Instructions

### Step 1: Set Up MySQL Database
1. Open MySQL Workbench or MySQL command line
2. Run the SQL file:
   ```sql
   source /path/to/RestaurantSystem/sql/schema.sql
   ```
   This creates the `restaurant_db` database with all tables and sample menu data.

### Step 2: Configure DB Connection
Open `src/restaurant/util/DBConnection.java` and update:
```java
private static final String USER     = "root";         // your MySQL username
private static final String PASSWORD = "your_password"; // your MySQL password
```

### Step 3: Add MySQL JDBC Driver
Download `mysql-connector-j-8.x.x.jar` from:
https://dev.mysql.com/downloads/connector/j/

In IntelliJ IDEA:
- File → Project Structure → Libraries → + → Java → select the JAR

### Step 4: Run the Project
- Right-click `Main.java` → Run
- OR compile and run from terminal:
```bash
javac -cp ".;mysql-connector-j-8.x.x.jar" -d out src/restaurant/**/*.java src/restaurant/Main.java
java  -cp "out;mysql-connector-j-8.x.x.jar" restaurant.Main
```

---

## How to Use

| Option | Action |
|--------|--------|
| 1 | View full menu with prices |
| 2 | Place a new customer order |
| 3 | View kitchen queue (pending orders) |
| 4 | Generate bill/invoice for an order |
| 5 | View all orders and their status |
| 6 | Admin: Add a new menu item |
| 0 | Exit |

---

## Technologies Used
- **Java** (Core Java, OOP: Encapsulation, Abstraction, Inheritance, Polymorphism)
- **MySQL** (Relational DB, Foreign Keys, Transactions, JOINs)
- **JDBC** (PreparedStatement, ResultSet, Batch Execution, Transactions)
- **IDE**: IntelliJ IDEA / Eclipse

---

## Key Features
- Full order lifecycle: Place → Kitchen → Bill
- Automatic kitchen queue update on order placement
- Transaction-safe order saving (commit/rollback)
- Formatted invoice with tax calculation
- Modular DAO + Service architecture
